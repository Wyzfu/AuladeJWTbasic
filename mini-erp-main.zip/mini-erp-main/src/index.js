const express = require("express");

const database = require("./database.js")

const routes = require("./routes.js");
const port = require("./config.js").port;

const app = express();

(async () => {
  
  const Cliente = require("./model/cliente.js")
  
  await database.sync({
    alter : true
  });
})

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use("/", routes);

app.listen(port, () => {
  console.log(`Listening on port ${port}`);
});
