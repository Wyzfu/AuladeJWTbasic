//Configuraçao do BD

const Sequelize = require('sequelize');
const sequelize = new Sequelize ('exemplo','root','positivo',{
    dialect:'mysql',
    host:'localhost',
    port:3306
}); //Constrói o obj responsável por abstrair o BD

module.exports= sequelize;