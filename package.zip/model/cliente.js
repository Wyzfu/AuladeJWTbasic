//Classe model para clientes

const Sequelize = require('sequelize');
const database = require('../db.js');


const Cliente = database.define('cliente',{
    id:{
        type: Sequelize.INTEGER,
        allowNull:false,
        primaryKey: true
    },
    nome:{
        type: Sequelize.STRING,
        allowNull:false
    },
    cpf:{
        type: Sequelize.STRING,
        allowNull:false
    },
    email:{
        type: Sequelize.STRING,
        allowNull:true
    }
    
});

module.exports = Cliente;