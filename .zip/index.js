/*
Primeiro programa em Node
Autor:Escobar, o bela
Data? 03/04/2023
*/

//Instanciar o express
const auth = require('./auth.js');
// const moment = require('moment');
const express = require('express');
const app = express();

require('dotenv').config() //Instanciano do .env

app.use(express.json());


//Cria a rota principal http://localhost:porta/
app.get('/',(req,res)=>{
    res.send('Opa! To na Ã¡rea!');
    
});

app.get('/hora', (req,res)=>{
    const t = Date.now();
    const data = moment().format('HH:mm:ss');
    console.log(data);
    res.send(data);
});

app.post('/login',(req,res)=>{
    const user = req.body;
    auth.autentica(user);
    res.send(user);

});


//Rota autenticada
app.post('/user/save', auth.verificaToken, (req,res)=>{
    console.log('Autenticou');
    res.send("ok");
});


//No final do index.js, ativar o servidor
const PORT = 3000;
app.listen(PORT, ()=>{
    console.log(`Servidor rodando na porta ${PORT}`);
});